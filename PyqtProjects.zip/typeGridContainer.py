"""
用于容纳靓号类型
"""
import sys

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QApplication

from typeGrid import TypeGridWidget


class TypeGridContainer(QWidget):

    def __init__(self, h_layout_num=2, grid_num_per_row=10):
        super().__init__()
        self.h_layout_num = h_layout_num       # 两行
        self.grid_num_per_row = grid_num_per_row    # 一行10个格子
        self.grid_num = 0             # 现在的格子数量
        self.initUI()

    def initUI(self):
        self.v_layout = QVBoxLayout()
        self.h_layout_list = []
        for i in range(self.h_layout_num):
            self.h_layout_list.append(QHBoxLayout())
            h_widget = QWidget()
            h_widget.setLayout(self.h_layout_list[i])
            self.v_layout.addWidget(h_widget)

        self.setLayout(self.v_layout)

    def add_grid(self, grid):
        # 如果已经满了, 就不添加
        if self.grid_num > self.h_layout_num * self.grid_num_per_row-1:
            return False
        # print(self.grid_num)
        row_idx = self.grid_num//self.grid_num_per_row     # 先看看要放在哪一行
        self.h_layout_list[row_idx].addWidget(grid)
        self.grid_num += 1
        return True


if __name__ == '__main__':
    app = QApplication(sys.argv)

    main = TypeGridContainer()

    for idx, name in enumerate(["所有号码", "自定义规则", "全段3A(AAA)", "尾号3拖1",
                                "尾abababab", '*a*a*a*a',
                                "真山", "顺子", "豹子", "尾号AAAAB", "倒顺",
                                "5A", "中间4A", "尾号ABC", '尾号CBA', "ababab", "aaabbb",
                                "中间ABCDE", "3数字组合", '1349风水号', 'AAABCD', 'aabbccdd', 'AAAA*A',
                                "abcdeabcde", "dcbadcba", "abacadae"]):

        grid = TypeGridWidget(name)
        main.add_grid(grid)
    main.show()

    sys.exit(app.exec_())

