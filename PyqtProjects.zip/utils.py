import inspect

import requests
import re

from PyQt5.QtCore import QSettings
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *

def ascending(num):
    if num[-1] == num[-3] == num[-5] == num[-7]:
        if int(num[-2]) - int(num[-4]) == int(num[-4]) - int(num[-6]) == int(num[-6]) - int(num[-8]):
            return True
        else:
            return False

    elif num[-2] == num[-4] == num[-6] == num[-8]:
        if int(num[-1]) - int(num[-3]) == int(num[-3]) - int(num[-5]) == int(num[-5]) - int(num[-7]):
            return True
        else:
            return False
    else:
        return False


def get_area_info():
    try:
        headers = {
            'Referer': 'https://msgo.10010.com/newMsg/onLineGo/html/fill.html?sceneFlag=03&goodsId=981610241535&productName=%E5%A4%A7%E7%8E%8B%E5%8D%A1&channel=9999&p=51&c=558&u=rSqV6hmVlPRu8PHYYIjcUQ==&s=02,03&sceneFlag=03',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36',
        }

        response = requests.get('https://res.mall.10010.cn/mall/front/js/areaInfo.js', headers=headers)
        area_info_dict = eval(re.search("[{].*[}]", response.text).group())
        print("省份和城市列表:", area_info_dict)  # ESS_PROVINCE_CODE
        return area_info_dict
    except Exception as e:
        print(e, "获取省份和城市列表失败")


def classify_num(num, custom_rules=None):
    type_of_card = ['所有号码']
    match_index_dict = {'所有号码': (0, 11), '尾abababab': (3, 11), '顺子': (7, 11),
                        '中ABCDE': (3, 8), '炸弹': (7, 11), '真山': (7, 11), '豹子': (8, 11), '尾aabbcc': (5, 11),
                        '4拖1': (6, 11), '尾ababab': (5, 11), '尾号ABC': (8, 11), '尾号CBA': (8, 11), '*a*a*a*a': (3, 11),
                        'abcdeabcde': (1, 11), '双顺子': (5, 11), 'ABBBCCCD': (3, 11), '镜子号': (3, 11)}

    if num[3:7][::-1] == num[-4:]:
        type_of_card.append('镜子号')

    if custom_rules is not None:
        for rule in custom_rules:
            if re.search(rule.replace('*', '.'), num):
                type_of_card.append('自定义规则')

    if re.search('([\\d])\\1{2}', num[-4:-1]) and re.search('([\\d])\\1{2}', num[-8:-5]):
        type_of_card.append('ABBBCCCD')

    if re.search(
            "(?:0(?=1)|1(?=2)|2(?=3)|3(?=4)|4(?=5)|5(?=6)|6(?=7)|7(?=8)|8(?=9)){3,}\\d",
            num[-4:]):
        type_of_card.append('顺子')

    if re.search(
            "(?:0(?=1)|1(?=2)|2(?=3)|3(?=4)|4(?=5)|5(?=6)|6(?=7)|7(?=8)|8(?=9)){2,}\\d",
            num[-3:]) and re.search("(?:0(?=1)|1(?=2)|2(?=3)|3(?=4)|4(?=5)|5(?=6)|6(?=7)|7(?=8)|8(?=9)){2,}\\d",
            num[-6:-3]):
        if '012' != num[-3:] and '012' != num[-6:-3]:
            type_of_card.append('双顺子')

    if re.search(
            "(?:1(?=2)|2(?=3)|3(?=4)|4(?=5)|5(?=6)|6(?=7)|7(?=8)|8(?=9)){2,}\\d",
            num[-3:]):
        type_of_card.append('尾号ABC')

        if re.search('([\\d])\\1{2}', num[-6:-3]):
            type_of_card.append('AAABCD')
            match_index_dict['AAABCD'] = (5, 11)

    if re.search('(?:9(?=8)|8(?=7)|7(?=6)|6(?=5)|5(?=4)|4(?=3)|3(?=2)|2(?=1)|1(?=0)){2,}\\d', num[-3:]):
        type_of_card.append('尾号CBA')

    if re.search(
            "(?:0(?=1)|1(?=2)|2(?=3)|3(?=4)|4(?=5)|5(?=6)|6(?=7)|7(?=8)|8(?=9)){4,}\\d",
            num[3:8]):
        type_of_card.append('中ABCDE')

    if re.search('([\\d])\\1{3}', num[-4:]):
        type_of_card.append('炸弹')

    if num[-8: -4] == num[-4:]:
        type_of_card.append('真山')

    if num[-10: -5] == num[-5:]:
        type_of_card.append('abcdeabcde')

    if re.search('([\\d])\\1{2}', num[-3:]):
        type_of_card.append('豹子')

    elif re.search('([\\d])\\1{2}', num[3:]):
        type_of_card.append('全段3A(AAA)')
        match_index_dict['全段3A(AAA)'] = re.search('([\\d])\\1{2}', num).span()

    if re.search('([\\d])\\1{2}', num[-4:-1]):
        type_of_card.append('尾号3拖1')
        match_index_dict['尾号3拖1'] = (7, 10)

    if re.search('(\\d)\\1\\1\\1(\\d)\\1', num[-6:]):
        type_of_card.append('AAAA*A')
        match_index_dict['AAAA*A'] = (5, 11)

    # ret = re.search(
    #         '(?:9(?=8)|8(?=7)|7(?=6)|6(?=5)|5(?=4)|4(?=3)|3(?=2)|2(?=1)|1(?=0)){5,}\\d', num[1:])
    # if ret:
    #     type_of_card.append'倒顺')
    #     s, e = ret.span()a
    #     match_index_dict['倒顺'] = (s+1, e+1)

    if re.search(
            '(?:9(?=8)|8(?=7)|7(?=6)|6(?=5)|5(?=4)|4(?=3)|3(?=2)|2(?=1)|1(?=0)){4,}\\d', num[-5:]):
        type_of_card.append('倒5顺')
        match_index_dict['倒5顺'] = (6, 11)

    if re.search(
            '(?:9(?=8)|8(?=7)|7(?=6)|6(?=5)|5(?=4)|4(?=3)|3(?=2)|2(?=1)|1(?=0)){3,}\\d', num[-4:]):
        type_of_card.append('倒4顺')
        match_index_dict['倒4顺'] = (7, 11)

    if re.search("(\\d)\\d\\1\\d\\1\\d\\1\\d", num[-8:]):
        # abacadae
        a, b, c, d = int(num[-7]), int(num[-5]), int(num[-3]), int(num[-1])
        if d-c == c-b == b-a == 1:
            type_of_card.append('abacadae')
            match_index_dict['abacadae'] = (3, 11)

    ret = re.search('(\\d)\\1\\1(\\d)\\2\\2', num[3:])  # aaabbb
    if ret:
        type_of_card.append('aaabbb')
        match_index_dict['aaabbb'] = re.search('(\\d)\\1\\1(\\d)\\2\\2', num).span()

    if re.search('(\\d)\\1(\\d)\\2(\\d)\\3', num[-6:]):  # aabbcc
        type_of_card.append('尾aabbcc')
    if re.search('(\\d)\\1(\\d)\\2(\\d)\\3(\\d)\\4', num[-8:]):  # aabbccdd
        type_of_card.append('aabbccdd')
        match_index_dict['aabbccdd'] = re.search('(\\d)\\1(\\d)\\2(\\d)\\3(\\d)\\4', num[-8:]).span()
    # if re.search('(\\d)\\1(\\d)\\2(\\d)\\3\\3(\\d)', num[-8:]):  # aabbcccd
    #     type_of_card.append('aabbcccd')
    # if re.search('(\\d)(\\d)\\1\\2(\\d)\\3\\3(\\d)', num[-8:]):  # ababcccd
    #     type_of_card.append('ababcccd')
    # if re.search('(\\d)(\\d)\\1\\2(\\d)\\3(\\d)\\4', num[-8:]):  # ababccdd
    #     type_of_card.append('ababccdd')

    ret = re.search('([\\d])\\1{4}', num)
    if ret:
        type_of_card.append('5A')
        match_index_dict['5A'] = ret.span()

    if re.search('([\\d])\\1{3}', num[-5:-1]):
        type_of_card.append('4拖1')
    if re.search('([\\d])\\1{3}', num[3:-2]):
        type_of_card.append('中间4A')
        s, e = re.search('([\\d])\\1{3}', num[3:-2]).span()
        match_index_dict['中间4A'] = (s + 3, e + 3)

    if num[-6: -4] == num[-4:-2] == num[-2:]:
        type_of_card.append('尾ababab')
    if re.search('000[1|8]', num[-4:]):  # 0001 或0008
        type_of_card.append('0001或0008')
    if re.search('(\\d)\\1\\1(8)', num[-4:]):  # XXX8
        type_of_card.append('XXX8')
    if re.search('(\\d)(\\d)(\\d)\\1\\2\\3', num[-6:]):  # abcabc
        if int(num[-1]) - int(num[-2]) == int(num[-2]) - int(num[-3]) == 1:
            type_of_card.append('abcabc')

    # if re.search('(\\d)\\1(\\d)\\2', num[-8:-4]):  # AABBxABC
    #     if int(num[-1]) - int(num[-2]) == int(num[-2]) - int(num[-3]) == 1:
    #         type_of_card.append('AABBxABC')

    # if re.search('(\\d)(\\d)\\1\\2', num[-8:-4]):  # ABABxABC
    #     if int(num[-1]) - int(num[-2]) == int(num[-2]) - int(num[-3]) == 1:
    #         type_of_card.append('ABABxABC')

    # if re.search('(\\d)\\1\\1', num[-8:-5]):  # AAABxABC
    #     if int(num[-1]) - int(num[-2]) == int(num[-2]) - int(num[-3]) == 1:
    #         type_of_card.append('AAABxABC')

    if re.search('(\\d)(\\d)\\1\\2\\1\\2', num[3:]):  # ababab
        type_of_card.append('ababab')
        match_index_dict['ababab'] = re.search('(\\d)(\\d)\\1\\2\\1\\2', num).span()

    if re.search('(\\d)(\\d)\\1\\2\\1\\2\\1\\2', num[-8:]):  # abababab
        type_of_card.append('尾abababab')
    if re.search('(\\d)(\\d)\\1\\2(\\d)(\\d)\\3\\4', num[-8:]):  # ababcdcd
        type_of_card.append('ababcdcd')
    if re.search('^\\d*(\\d)\\1\\1.(\\d)\\2\\2\\d*$', num[-8:]):  # aaabcccd
        type_of_card.append('aaabcccd')
    if re.search('1688', num[-4:]):  # '1688'
        type_of_card.append('1688')
    if re.search('10086', num[-5:]):  # '10086'
        type_of_card.append('10086')
    # elif re.search('1314', num[-4:]):  # '1314'
    #     type_of_card.append('1314')
    if re.search('^\\d*(\\d)\\1\\1.(\\d)\\2(\\d)\\3.*$', num[-8:]):  # aaabccdd
        type_of_card.append('aaabccdd')
    if len(set(num)) == 3:
        type_of_card.append('3数字组合')
    if re.search('(\\d)\\1(88)', num[-4:]):
        type_of_card.append('AA88')
    if set(num) == {'1', '3', '4', '9'}:
        type_of_card.append('1349风水号')
    if ascending(num):
        type_of_card.append('*a*a*a*a')
    if re.search('(\\d)\\1(\\d)\\2(\\d)\\3(\\d)\\4', num[-8:]):
        type_of_card.append('四对')
    if num[-6:] == '678910':
        type_of_card.append('678910')
    if num[-5:] == '67890':
        type_of_card.append('67890')

    if re.search('888\\d8', num[-5:]):  # 888X8
        type_of_card.append('888X8')

    if re.search('8\\d88', num[-4:]):  # 8X88
        type_of_card.append('8X88')

    if num[-6:] == '131419':
        type_of_card.append('131419')

    if num[-6:] == '141319':
        type_of_card.append('141319')

    if num[-7:] == '1314520':
        type_of_card.append('1314520')

    if num[-7:] == '1314521':
        type_of_card.append('1314521')

    if num[-6:] == '201314':
        type_of_card.append('201314')

    if re.search('(\\d)(\\1)(\\1)520', num[-6:]):
        type_of_card.append('AAA520')

    if re.search('(\\d)(\\1)(\\1)521', num[-6:]):
        type_of_card.append('AAA521')

    # # 有问题
    # if re.search('(\\d)88(\\d)(\\d)88(\\d)', num):
    #     s, e = re.search('(\\d)88(\\d)(\\d)88(\\d)', num)
    #     num_of_interest = num[s: e]
    #     if num_of_interest[0] == num_of_interest[3] and num_of_interest[4] == num_of_interest[7]:
    #         type_of_card.append('A88AB88B')
    #
    # if re.search('8(\\d)(\\d)88(\\d)(\\d)8', num):
    #     s, e = re.search('8(\\d)(\\d)88(\\d)(\\d)8', num)
    #     num_of_interest = num[s: e]
    #     if num_of_interest[1] == num_of_interest[2] and num_of_interest[5] == num_of_interest[6]:
    #         type_of_card.append('8AA88BB8')

    return type_of_card, match_index_dict


def GetHandledTypes():
    return QComboBox, QLineEdit, QCheckBox, QRadioButton, QSpinBox, QSlider, QListWidget, QTextEdit


def IsHandledType(widget):
    return any(isinstance(widget, t) for t in GetHandledTypes())


def GuiSave(ui: QWidget, settings: QSettings, uiName="uiwidget"):
    namePrefix = f"{uiName}/"
    settings.setValue(namePrefix + "geometry", ui.saveGeometry())

    for name, obj in inspect.getmembers(ui):
        if not IsHandledType(obj):
            continue

        name = obj.objectName()
        value = None
        if isinstance(obj, QComboBox):
            index = obj.currentIndex()  # get current index from combobox
            value = obj.itemText(index)  # get the text for current index

        if isinstance(obj, QLineEdit):
            value = obj.text()

        if isinstance(obj, QCheckBox):
            value = obj.isChecked()

        if isinstance(obj, QRadioButton):
            value = obj.isChecked()

        if isinstance(obj, QSpinBox):
            value = obj.value()

        if isinstance(obj, QSlider):
            value = obj.value()

        if isinstance(obj, QTextEdit):
            value = obj.toPlainText()

        if isinstance(obj, QListWidget):
            settings.beginWriteArray(name)
            for i in range(obj.count()):
                settings.setArrayIndex(i)
                settings.setValue(namePrefix + name, obj.item(i).text())
            settings.endArray()
        elif value is not None:
            settings.setValue(namePrefix + name, value)

#===================================================================
# restore "ui" controls with values stored in registry "settings"
#===================================================================

def GuiRestore(ui : QWidget, settings : QSettings, uiName="uiwidget"):
    from distutils.util import strtobool

    namePrefix = f"{uiName}/"
    geometryValue = settings.value(namePrefix + "geometry")
    if geometryValue:
        ui.restoreGeometry(geometryValue)

    for name, obj in inspect.getmembers(ui):
        if not IsHandledType(obj):
            continue

        name = obj.objectName()
        value = None
        if not isinstance(obj, QListWidget):
            value = settings.value(namePrefix + name)
            if value is None:
                continue

        if isinstance(obj, QComboBox):
            index = obj.findText(value)  # get the corresponding index for specified string in combobox

            if index == -1:  # add to list if not found
                obj.insertItems(0, [value])
                index = obj.findText(value)
                obj.setCurrentIndex(index)
            else:
                obj.setCurrentIndex(index)  # preselect a combobox value by index

        if isinstance(obj, QLineEdit):
            obj.setText(value)

        if isinstance(obj, QCheckBox):
            obj.setChecked(strtobool(value))

        if isinstance(obj, QRadioButton):
            obj.setChecked(strtobool(value))

        if isinstance(obj, QSlider):
            obj.setValue(int(value))

        if isinstance(obj, QSpinBox):
            obj.setValue(int(value))

        if isinstance(obj, QTextEdit):
            obj.setText(value)

        if isinstance(obj, QListWidget):
            size = settings.beginReadArray(namePrefix + name)
            for i in range(size):
                settings.setArrayIndex(i)
                value = settings.value(namePrefix + name)
                if value is not None:
                    obj.addItem(value)
            settings.endArray()


if __name__ == '__main__':
    get_area_info()
