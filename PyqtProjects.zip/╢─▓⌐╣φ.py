
import random

# 一次的赌资
gambling_fund = 2.88

# 总收益
earnings = 0


price_list = [0, 0.88, 1.88, 3.88, 8.88, 12.88, 28.88]

for i in range(10000):

    earnings -= gambling_fund    # 下注
    # 开始赌博
    lucky_number = random.randrange(1, 7)    # 幸运数字
    winning_number = random.randrange(1, 7)     # 中奖数字
    if winning_number <= (7-lucky_number):
        earnings += price_list[lucky_number]
        print("赚了:", price_list[lucky_number]-gambling_fund)
    else:
        print("亏了:", gambling_fund)

    # print(f"赌{i}次, 现在还剩下:￥{earnings}")
