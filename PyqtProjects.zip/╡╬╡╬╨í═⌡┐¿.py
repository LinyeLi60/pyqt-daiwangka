import requests
import json

cookies = {
    'UID': 'MKkUnB7tp7d5Lr3cmNXuu5l2uWvECW3F',
    'tianjincity': '11|110',
    'tianjin_ip': '0',
    'mallcity': '11|110',
    'gipgeo': '11|110',
}

headers = {
    'Origin': 'https://msgo.10010.com',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1',
    'Content-Type': 'application/json',
    'Accept': '*/*',
    'Referer': 'https://msgo.10010.com/newMsg/onLineGo/html/fill.html?sceneFlag=03&goodsId=981712203627&productName=%E6%BB%B4%E6%BB%B4%E5%B0%8F%E7%8E%8B%E5%8D%A1&channel=9999&p=51&c=558&u=rSqV6hmVlPRu8PHYYIjcUQ==&s=03,02',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
}

data = '{"numInfo":{"essProvince":"51","essCity":"558","number":"13172999353"},"goodInfo":{"goodsId":"981712203627","sceneFlag":"03"},"postInfo":{"webProvince":"440000","webCity":"442000","webCounty":"442025","address":"\u4E2D\u5C71\u5927\u5B66"},"certInfo":{"certTypeCode":"02","certName":"\u89E3\u65B0\u8339","certId":"230281199702044343","contractPhone":"13777789388"},"u":"rSqV6hmVlPRu8PHYYIjcUQ==","channel":"9999","marketingStatus":"0"}'


response = requests.post('https://msgo.10010.com/scene-buy/scene/buy', headers=headers, cookies=cookies, data=data)
