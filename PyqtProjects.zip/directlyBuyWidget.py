"""
直接输入号码进行下单
"""
import json
import sys

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtWidgets import QWidget, QHBoxLayout, QComboBox, QLineEdit, QPushButton, QApplication, QMessageBox


class DirectlyBuyWidget(QWidget):

    buyNumberSender = pyqtSignal(str, str, str, str, bool)
    cancel_number_sender = pyqtSignal(str)  # 对这个号码取消持续下单

    def __init__(self, meal_dict):
        super().__init__()
        self.meal_dict = meal_dict
        self.initUI()
        self.initData()
        self.initListener()

    def initUI(self):

        layout = QHBoxLayout()
        self.meal_type_combobox = QComboBox()
        self.province_list_combobox = QComboBox()
        self.city_list_combobox = QComboBox()
        # self.city_list_combobox.setFixedWidth(200)
        self.number_line_edit = QLineEdit("填下单号码")
        self.number_line_edit.setFixedWidth(300)
        self.pushButton = QPushButton("点击下单一次")
        self.pushButtonRepeat = QPushButton("重复下单直到成功为止")
        self.pushButtonCancel = QPushButton("取消该号码持续下单")
        layout.addWidget(self.meal_type_combobox)
        layout.addWidget(self.province_list_combobox)
        layout.addWidget(self.city_list_combobox)
        layout.addWidget(self.number_line_edit)
        layout.addWidget(self.pushButton)
        layout.addWidget(self.pushButtonRepeat)
        layout.addWidget(self.pushButtonCancel)
        self.setLayout(layout)

        self.meal_type_combobox.addItems(self.meal_dict.keys())

    def initData(self):
        # 保存信息
        with open("area_code.json", 'r') as f:
            total_dict = json.load(f)
            self.provinceCodeToName = total_dict['provinceCodeToName']
            self.provinceNameToCode = total_dict['provinceNameToCode']
            self.cityNameToCode = total_dict['cityNameToCode']
            self.cityCodeToName = total_dict['cityCodeToName']
            self.provinceNameToCityNameList = total_dict['provinceNameToCityNameList']

    def initListener(self):
        self.province_list_combobox.addItems(self.provinceNameToCityNameList.keys())
        self.province_list_combobox.activated[str].connect(self.update_city_list_combobox)
        self.update_city_list_combobox(self.province_list_combobox.currentText())

        self.pushButton.clicked.connect(self.buy)
        self.pushButtonRepeat.clicked.connect(self.repeatBuy)
        self.pushButtonCancel.clicked.connect(self.calcelBuy)

    def update_city_list_combobox(self, province_name):
        self.city_list_combobox.clear()
        self.city_list_combobox.addItems(self.provinceNameToCityNameList[province_name])

    def calcelBuy(self):
        number = self.number_line_edit.text().strip()
        if number == "" or number == "填下单号码" or number.__len__() != 11:
            QMessageBox.information(self, "提示", "请先填写号码")
        else:
            self.cancel_number_sender.emit(number)

    def repeatBuy(self):
        province = self.province_list_combobox.currentText()
        city = self.city_list_combobox.currentText()
        number = self.number_line_edit.text().strip()
        meal_name = self.meal_type_combobox.currentText()
        if number == "" or number == "填下单号码" or number.__len__() != 11:
            QMessageBox.information(self, "提示", "请先填写号码")
        else:
            self.buyNumberSender.emit(number, province, city, meal_name, True)

    def buy(self):
        province = self.province_list_combobox.currentText()
        city = self.city_list_combobox.currentText()
        number = self.number_line_edit.text().strip()
        meal_name = self.meal_type_combobox.currentText()
        if number == "" or number == "填下单号码" or number.__len__() != 11:
            QMessageBox.information(self, "提示", "请先填写号码")
        else:
            self.buyNumberSender.emit(number, province, city, meal_name, False)


if __name__ == '__main__':
    app = QApplication(sys.argv)

    main = DirectlyBuyWidget()
    main.show()

    sys.exit(app.exec_())